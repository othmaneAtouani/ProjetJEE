package org.mrb.authservice.sec.dao;

import lombok.Data;

@Data
public class RoleUserForm{
    private String username;
    private String roleName;
}
